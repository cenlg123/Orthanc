#ifndef _SIM800_H_
#define _SIM800_H_

#include "getNmap.h"

typedef enum  
{  
    AT_RETURN_OK            =       0,      //返回成功  
    AT_RETURN_ERROR         =       1,      //返回错误  
    AT_RETURN_UNKNOWN       =       2,      //返回结果未知
    AT_RETURN_TIME_OUT      =       0xf,    //等待返回超时  
}SIM800_ERROR; 

typedef struct
{
	uint8_t SCA[16];			// 服务地址可设置为0,不计入PDU总长度
	uint8_t FO;					// FO 设置PDU类型
	uint8_t MR;					// MR 发送参考号
	uint8_t DAL;				// 目标号码长度
	uint8_t DA_Type;			// 目的号码类型
	uint8_t DA[16];             // DA 
	uint8_t PID;                // PID 发送方式
	uint8_t DCS;                // DCS 编码模式。08表示class1,18表示class0
	uint8_t VP;                 // VP 有效区
	uint16_t UDL;                // UDL 数据长度
	uint8_t UD[1024];			// 发送信息
}SIM800_PDU_Send;

bool_t SIM800_Ready( void );

void SIM800_SendATCom( 	 	   uint8_t *pTxBuff);

bool_t SIM800_RecvSMS( 		   uint8_t *pRxBuff );

bool_t SIM800_Del_SentSMS();

uint32_t SIM800_GetRxBuf( 	   uint8_t *pRxBuff, uint32_t nBufLen, uint32_t timeout );

SIM800_ERROR SIM800_GetATResp( uint8_t *pRxBuff, const char *pKeyword, uint32_t TimeOut );

					   
uint16_t SIM800_PDU_Content(const uint8_t* Mobile_Number,const uint8_t* SMS_Content,uint8_t* Send_Buff);

bool_t SIM800_PDU_Msg_Send(uint8_t* Send_Buff,uint16_t PDU_Len);

bool_t SIM800_TEXT_Msg_Send(const uint8_t* Mobile_Number,uint8_t* SMS_Content);

int ErgodicNmap(IP_addr* ip_Addr, uint8_t * p);

void* schneider_pth(void* arg);

void* delta_pth(void* arg);

void* Micro_850_pth(void* arg);

void* Moxa_pth(void* arg);

#endif