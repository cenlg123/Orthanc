/**********************************************************************************************************
 *  A. Standard Includes
*********************************************************************************************************/
#include <stdio.h>  
#include <string.h> 
#include <stdlib.h>
#include <stdint.h>
#include <pthread.h>


/**********************************************************************************************************
 *  B. APP sepecific Includes
*********************************************************************************************************/
#include "invade.h"
#include "ser.h"
#include "getNmap.h"
#include "SIM800.h"
#include "client.h"

/**********************************************************************************************************
 *  C. Object like Macro
*********************************************************************************************************/

/**********************************************************************************************************
 *  D. Function like Macro
*********************************************************************************************************/

#if SER_CFG_ENABLE_LOG
    #define LOG( _level, ... )  fprintf( stdout, "[%s]", #_level, __VA_ARGS__ )
#else
    #define LOG( _level, ... )   
#endif

/**********************************************************************************************************
 *  E. Type defines
**********************************************************************************************************/

/**********************************************************************************************************
 *  F. Local Function Declarations
**********************************************************************************************************/
/*********************************************************************************************************
 * @brief  初始化所需要的功能
 *
 * @param   void
 * @usage
 *
 * @return  TRUE  1
 *          FALSE 0
 *          
 *
********************************************************************************************************/
bool_t invade_Init( )
{
	bool_t  bSuccess;
	bSuccess = SER_Init();
	
	if ( bSuccess ) 
	{
		bSuccess =  SER_Open( SER_ePort0 );
		if( !bSuccess )
		{
			LOG( INVADE_ERROR, "Open Serial Failure!\r\n" );
		}
	}

	if ( bSuccess )
	{
		bSuccess = SER_SetSerial(  SER_ePort0,
                    115200,
                    8,
                    2,
                    1 );
		if( !bSuccess )
		{
			LOG( INVADE_ERROR, "Serial Cfg Failure!\r\n" );
		}
	}

	
	if ( bSuccess )
	{
		bSuccess = SIM800_Ready();
		if( !bSuccess )
		{
			LOG( INVADE_ERROR, "SIM800 Synchronous Failure!\r\n" );
		}
	}
	return bSuccess;
}


/*********************************************************************************************************
 * @brief   监听串口信息
 *
 * @param   void
 * @usage
 *
 * @return  void
 *          
 *
********************************************************************************************************/
 static void invade_StartListening()
 {
 	bool_t bSuccess;

 	bSuccess = SER_RxEnable(SER_ePort0);	
 	if( !bSuccess )
 	{
 		LOG( INVADE_ERROR, "Serial Cfg Failure!\r\n" );
 	}
 	else
 	{
 		LOG( INVADE_INFO, "Serial Cfg Done!\r\n");
 	}

 	do
 	{
		SER_RxTx();
 	}while(1);

 }

/**********************************************************************************************************

************************************************************************************************************/
void* listen_thread(void* arg)
{
	invade_StartListening();
}


/*********************************************************************************************************
 * @brief   main
 *
 * @param   void
 * @usage
 *
 * @return  void
 *          
 *
********************************************************************************************************/
int main (int argc, char *argv[])
{
	bool_t  bSuccess;
	int rc;
	pthread_t tid;
	bSuccess = invade_Init();
	if( bSuccess )
    {
        LOG( INVADE_INFO, "Initialization Done!\r\n" );
    }
    else
    {
        LOG( INVADE_ERROR, "Initialization Failure!\r\n" );
    }

   /* Start system Main Loop */
    if( bSuccess )
    {
    	rc = pthread_create(&tid, NULL, listen_thread, NULL);
    	if (rc != 0)
    	{
    		LOG(CREATE_ERROR, "Create Pthread Failure!\r\n");
    	}
    }
    pthread_join(tid, NULL);
}

