#ifndef _GETNMAP_H_
#define _GETNMAP_H_

#define MAX_SIZE  100  //buff大小
#define IP_SIZE   30   //ip大小
#define IP_NUM    30   //最多可以存取ip的数量
#define MAC_SIZE  18   //MAC大小 
#define PORT_NUM  30   //每个ip最多可以存取port的数量 
#define PORT_SIZE 40   //port的大小


typedef struct ip_arr
{
	char ip[IP_SIZE];
	char MAC[MAC_SIZE];
	char port[PORT_NUM][PORT_SIZE];
	int port_count;
}IP_arr;

typedef struct ip_addr
{
	int ip_count;
	IP_arr * IpAddr;
}IP_addr;

IP_addr* getNmap();
int getPLC();
int getallPLC();

#endif 