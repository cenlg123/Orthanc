#ifndef _SER_H_
#define _SER_H_


/**********************************************************************************************************
 *  a. Object like Macro
*********************************************************************************************************/


/**********************************************************************************************************
 *  b. Function Like Macro
*********************************************************************************************************/
 
 
/**********************************************************************************************************
 *  C. Type Definition
*********************************************************************************************************/

typedef enum SER_eParity_t
{
    SER_eParityOdd  = 0u,
    SER_eParityEven,
    SER_eParityNone,
    
} SER_eParity_t;

typedef enum
{
    SER_ePort0 = 0u,
    
    
    SER_eNumPorts,
} SER_ePort_t;



/**********************************************************************************************************
 *  D. Object and Variables
*********************************************************************************************************/

 
 
 
/**********************************************************************************************************
 *  E. Function Prototypes
*********************************************************************************************************/

bool_t      SER_Init( void );

bool_t      SER_Open(       SER_ePort_t ePort );
bool_t      SER_OpenWithFd( SER_ePort_t ePort, int fd );
bool_t      SER_Close(      SER_ePort_t ePort );

bool_t      SER_SetSerial(  SER_ePort_t     ePort, 
                            uint32_t        uBaudRate, 
                            uint8_t         uDataBits, 
                            SER_eParity_t   eParity, 
                            uint8_t         uStopBits );
                        

bool_t      SER_TxEnable( SER_ePort_t ePort );
bool_t      SER_TxDisable( SER_ePort_t ePort );

bool_t      SER_RxEnable( SER_ePort_t ePort );
bool_t      SER_RxDisable( SER_ePort_t ePort );

uint32_t    SER_Read(   SER_ePort_t ePort, uint8_t *buff, uint32_t bufLen, uint32_t timeout );
bool_t      SER_Write(  SER_ePort_t ePort, uint8_t *buff, uint32_t bufLen );

void        SER_RxTx( void );

#endif //_SER_H_
