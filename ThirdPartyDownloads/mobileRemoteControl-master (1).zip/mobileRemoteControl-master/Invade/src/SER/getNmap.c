#include <stdio.h>  
#include <stdlib.h>  
#include <string.h>
#include <stdint.h>  
  
#include "invade.h.in"
#include "ser.h"
#include "getNmap.h"
#include "SIM800.h" 

char PLCbuff[1024];
 
IP_addr* getNmap()                   //nmap扫描
{  
    FILE *fstream = NULL;  
    int error=0; 
	int ip_count = 0;
	int mac_count = 0;
	int port_count = 0;
	int port_flag = 0;
    char buff[MAX_SIZE]={0};  
    char *p  = NULL;
	IP_arr *ip_mac_port = (IP_arr *)malloc(IP_NUM * sizeof(IP_arr));
	IP_addr *ip_addrs = (IP_addr *)malloc(sizeof(IP_addr));
	ip_addrs->IpAddr = ip_mac_port;
	printf("111111111111\n");
    if(NULL == (fstream=popen("nmap 192.168.1.130","r"))) //通过管道获取信息
    {  
        fprintf(stderr,"execute command failed:%s",strerror(error));  
        return -1;  
    }  
  
    while(fgets(buff,sizeof(buff),fstream) != NULL)  
    {  
        //printf("%s", buff);
        p = strstr(buff, "for");   //匹配获取所需信息
 		if (p != NULL)
		{
            if (strcmp(p+4, "192.168.6.21\n") == 0)
			{
			   break;
			}
			strcpy(ip_mac_port[ip_count].ip, p+4);
			ip_count++;
			continue;
		}

        p = strstr(buff, "PORT");
		if (p != NULL)
		{
			port_flag = 1;   //port获取开始
			memset(buff, 0, sizeof(buff));
			continue;
        }

		p = strstr(buff, "MAC");
		if (p != NULL)
		{
			strcpy(ip_mac_port[mac_count].MAC, p+13);
			ip_mac_port[mac_count].port_count = port_count;
			mac_count++;
			port_count = 0; //一个ip结束 port结束 数量清零
			port_flag = 0;
			continue;
		}																		
        if (port_flag == 1) //通过判断 获取具体端口信息数量的多少
		{
			strcpy(&(ip_mac_port[ip_count - 1].port[port_count][PORT_SIZE]), buff);
			memset(buff, 0, sizeof(buff));
			port_count++;
		}
    }  
    pclose(fstream);
    ip_addrs->ip_count = ip_count;
	printf("3333333333333\n");
    return ip_addrs;  
}  

int  getPLC()      //从文件中读取四组PLC设备的nmap扫描信息
{
	FILE *pFile;
    int len;
    if((pFile = fopen("/usr/local/src/mobileRemoteControl/Invade/src/SER/PLC_nmap.txt", "r")) == NULL) 
    {  
        printf("file cannot be opened/n");   
        return -1;   
    }   
	fseek(pFile, 0, SEEK_END);
	len = ftell(pFile);
	rewind(pFile);
	fread(PLCbuff, 1, len, pFile);
	PLCbuff[len] = 0;
	fclose(pFile);
}

int  getallPLC()      //从文件中读取全部PLC设备的nmap扫描信息
{
	FILE *pFile;
    int len;
    if((pFile = fopen("/usr/local/src/mobileRemoteControl/Invade/src/SER/All_PLC_nmap.txt", "r")) == NULL) 
    {  
        printf("file cannot be opened/n");   
        return -1;   
    }   
	fseek(pFile, 0, SEEK_END);
	len = ftell(pFile);
	rewind(pFile);
	fread(PLCbuff, 1, len, pFile);
	PLCbuff[len] = 0;
	fclose(pFile);
}