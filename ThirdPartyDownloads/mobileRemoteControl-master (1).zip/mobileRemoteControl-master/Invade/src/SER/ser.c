/**********************************************************************************************************
 *  A. Standard Includes
*********************************************************************************************************/


#include <errno.h>
#include <termios.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/select.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>

/**********************************************************************************************************
 *  B. APP sepecific Includes
*********************************************************************************************************/

#include "invade.h.in"
#include "ser.h"
#include "getNmap.h"
#include "SIM800.h"

/**********************************************************************************************************
 *  C. Object like Macro
*********************************************************************************************************/


#define SER_CFG_ENABLE_LOG          ( 0 ) 

#define SER_eNumPorts                 1 

#define SER_BUFF_SIZE               (1024u)
#define SERIAL_PORT_NAME            "/dev/ttyAMA0"
/**********************************************************************************************************
 *  D. Function like Macro
*********************************************************************************************************/

#if SER_CFG_ENABLE_LOG
    #define SER_LOG( _level, ... )  fprintf( stdout, "[%s]", #_level, __VA_ARGS__ )
#else
    #define SER_LOG( _level, ... )   
#endif

/**********************************************************************************************************
 *  E. Type defines
**********************************************************************************************************/

typedef struct
{
    struct termios              zSavedTmio;
    struct termios              zCurrentTmio;
    int                         fd;
    bool_t                      bOpened;
    
    bool_t                      bEnTx;
    bool_t                      bEnRx;
    
} ser_zPortStatus_t;

/**********************************************************************************************************
 *  F. Local Function Declarations
**********************************************************************************************************/
static  speed_t ser_TranslateBaudrate( uint32_t baudrate );

/**********************************************************************************************************
 *  G. Local Object/Variable
*********************************************************************************************************/


static ser_zPortStatus_t   ser_azPortStatus[ SER_eNumPorts ];
static bool_t              ser_bInitDone = FALSE;


/**********************************************************************************************************
 *  h. Exported Object/Variable
*********************************************************************************************************/


 
 
/**********************************************************************************************************
 *  I. Local Function Implementations
**********************************************************************************************************/


/**********************************************************************************************************
 *  J. Public Function Implementations
*********************************************************************************************************/

/*********************************************************************************************************
 * @brief   SER module init.
 *
 * @usage
 *
 * @return  TRUE if no error. 
 *          FALSE otherwise.
 *
 * 
********************************************************************************************************/
bool_t      SER_Init( void )
{
    memset( &ser_azPortStatus[0u], 0, sizeof( ser_azPortStatus ));
    ser_bInitDone = TRUE;
    
    return TRUE;
}

/*********************************************************************************************************
 * @brief   open the specified serial port. 
 *          and configure the port with proper setting ( from configuration )
 *
 * @param   ePort: the port being opened.
 * @usage
 *
 * @return  TRUE if no error. 
 *          FALSE otherwise.
 *
 * 
********************************************************************************************************/
bool_t SER_Open( SER_ePort_t ePort )
{
    bool_t          bSuccess = TRUE;
    int             fd = -1;

    if( ( ser_bInitDone ) &&
        ( ePort < SER_eNumPorts ) )
    {
        fd = open ( SERIAL_PORT_NAME , O_RDWR | O_NOCTTY | O_SYNC );
        if ( fd < 0 )
        {
            bSuccess = FALSE;
            fprintf( stdout, "error opening serial port %s: %s", SERIAL_PORT_NAME, strerror (errno));
        }
        else
        {
            bSuccess = SER_OpenWithFd( ePort, fd );
        }
    }
    
    if( ! bSuccess )
    {
        fd = -1;
    }
    
    return bSuccess;
}

/*********************************************************************************************************
 * @brief   for the sepcified port, with the specified file,
 *          - mark the port as opened.
 *          - configure the port with the setting from configuration.
 *
 * @usage
 *
 * @return  TRUE if no error. 
 *          FALSE otherwise.
 *
 * 
********************************************************************************************************/
bool_t SER_OpenWithFd( SER_ePort_t ePort, int fd )
{
    bool_t          bSuccess = TRUE;
    struct termios* pzTty;
    
    
    if( ( ser_bInitDone ) &&
        ( ePort < SER_eNumPorts ) &&
        ( fd >= 0 ))
    {
        
        ser_azPortStatus[ePort].fd      = fd;
        ser_azPortStatus[ePort].bOpened = TRUE;
        
        /* obtain current settting */
        tcgetattr( fd, &ser_azPortStatus[ePort].zSavedTmio );
        tcgetattr( fd, &ser_azPortStatus[ePort].zCurrentTmio );
        pzTty = &ser_azPortStatus[ePort].zCurrentTmio;
        
        //fprintf(stdout, "pzTty->c_cflag:%lX\r\n", pzTty->c_cflag);
        //fprintf(stdout, "pzTty->c_iflag:%lX\r\n", pzTty->c_iflag);
        //fprintf(stdout, "pzTty->c_oflag:%lX\r\n", pzTty->c_oflag);
        //fprintf(stdout, "pzTty->c_lflag:%lX\r\n", pzTty->c_lflag);

        /*------------------- Control Flags --------------------------------*/
        // CBAUD: (not in POSIX)
        // CSIZE: char size mask. CS5/CS6/CS7/CS8
        // CSTOPB: set:2StopBits, clear: 1.
        // CREAD: enable receiver.
        // PARENB: enable parity generation on output. parity chekcing for input.
        // PARODD: set:ODD. clear: even.
        // HUPCL: hang up after close the device.
        // CLOCAL: ignore modem control lines.
        
        pzTty->c_cflag |= (CLOCAL | CREAD);
        pzTty->c_cflag &= ~CSIZE;
        pzTty->c_cflag &= ~CRTSCTS;
        pzTty->c_cflag |= CS8;
        pzTty->c_cflag &= ~CSTOPB;
        // pzTty->c_cflag |= (CLOCAL | CREAD); // ignore modem controls,
        //                                     // enable reading
        
        // pzTty->c_cflag &= ~CRTSCTS; // NOT in POSIX, HW flow Control: RTS/CTS 
        
        /*------------------- Input Flags --------------------------------*/
        // IGNBRK: ignore break
        // BRKINT: cause flush.
        // IGNPAR: ignore framing errors and parity errors.
        // PARMRK: if IGNPAR not set, prefix parityErr/FramingErr with \377\0.
        //         if neither IGNPAR nor PARMRK is set, parityErr/FramingErr as \0.
        // INPCK: enable input parity checking
        // ISTRIP: strip off 8th bit.
        // INLCR:  translate NL to CR.
        // IGNCR:  ignore CR.
        // ICRNL:  translate CR to NL. (unless IGNCR is set )
        // IXON:  enable XON/XOFF on output
        // IXANY:  typing any char will restart stopped output.
        // IXOFF: enable XON/XOFF on input.

        pzTty->c_iflag |= IGNPAR;
        // pzTty->c_iflag &= ~IGNBRK; // disable break processing
        // pzTty->c_iflag &= ~(IXON | IXOFF | IXANY); // shut off xon/xoff ctrl
        
        /*------------------- Local Flags --------------------------------*/
        // ISIG: generate signal: INTR, QUIT, SUSP, DSUSP.
        // ICANON: enable canonical mode.
        // ECHO:  echo input char.
        // ECHOE: if ICANON, ERASE:preceding in char. WERASE:preceding word.
        // ECHOK: if ICANON, KILL: current line.
        // ECHONL: if ICANON, echo NL even if ECHO is not set.
        // NOFLSH: Disable flushing the input and output when INT, QUIT, and SUSP.
        // TOSTOP: Send the SIGTTOU signal to the process group who tries to write to its control term.
        // IDXTEN: enable implementation-defined input processing.

        pzTty->c_lflag = 0;
        // pzTty->c_lflag = ECHO|TOSTOP|ISIG;     // no signaling chars, no echo,
                                   // no canonical processing


        /*------------------- Output Flags --------------------------------*/
        // OPOST: enable implementation-defined output processing
        // OLCUC: map lowercase to upper case.
        // ONLCR: map CR to NL on outuput.
        // ONOCR: No output CR at column 0.
        // ONLRET: No output CR.
        // OFILL: send fill char for a delay, rather than using a timed delay.
        // OFDEL: fill char is ASCII DEL. otherwise NULL.
        // NLDLY: Newline delay mask.   NL0/NL1
        // CRDLY: CR delay mask.        CR0/CR1/CR2/CR3
        // TABDLY: horizontal tab delay mask. TAB0/TAB1/TAB2/TAB3.
        // BSDLY: backspace delay mask.  BS0/BS1
        // VTDLY: vertical delay mask.   VT0/VT1
        // FFDLY: form feed delay mask.  FF0/FF1.
        pzTty->c_oflag = 0; //ONLCR;     // no remapping, no delays
        
        /*------------------- Special Characters----------------------------*/
        // pzTty->c_cc[VMIN]  = 0; // read doesn't block
        // pzTty->c_cc[VTIME] = 5; // 0.5 seconds read timeout

        //fprintf(stdout, "pzTty->c_cflag:%lX\r\n", pzTty->c_cflag);
        //fprintf(stdout, "pzTty->c_iflag:%lX\r\n", pzTty->c_iflag);
        //fprintf(stdout, "pzTty->c_oflag:%lX\r\n", pzTty->c_oflag);
        //fprintf(stdout, "pzTty->c_lflag:%lX\r\n", pzTty->c_lflag);

        if( bSuccess )
        {
            if ( tcsetattr ( fd, TCSADRAIN, pzTty ) != 0)
            {
                SER_LOG ( SER_ERROR, "error %d from tcsetattr", errno);
                //bSuccess = FALSE;
            }

            //fprintf(stdout, "pzTty->c_cflag:%lX\r\n", pzTty->c_cflag);
            //fprintf(stdout, "pzTty->c_iflag:%lX\r\n", pzTty->c_iflag);
            //fprintf(stdout, "pzTty->c_oflag:%lX\r\n", pzTty->c_oflag);
            //fprintf(stdout, "pzTty->c_lflag:%lX\r\n", pzTty->c_lflag);
        }
    }
    else
    {
        bSuccess = FALSE;
    }
    
    if( ! bSuccess )
    {
        SER_LOG( SER_ERROR, "error" );
    }
    
    return bSuccess;
}



/*********************************************************************************************************
 * @brief   set serial port with the sepcified line describtion setting.
 *
 * @param   ePort:      the port being configured.
 * @param   uBaudRate:  baudrate being set.
 * @param   uDataBits:  number of data bits
 * @param   eParity:    parity configuration
 * @param   uStopBits:  number of stop bits.
 * @usage
 *
 * @return  TRUE if no error. 
 *          FALSE otherwise.
 *
 * 
********************************************************************************************************/
bool_t  SER_SetSerial(  SER_ePort_t     ePort, 
                        uint32_t        uBaudRate, 
                        uint8_t         uDataBits, 
                        SER_eParity_t   eParity, 
                        uint8_t         uStopBits )
{
    bool_t          bSuccess = TRUE;
    int             fd = -1;
    speed_t         speed;
    struct termios* pzTty;
    
    
    if( ( ser_bInitDone ) &&
        ( ePort < SER_eNumPorts ) &&
        ( ser_azPortStatus[ePort].fd >= 0 )&&
        ( ser_azPortStatus[ePort].bOpened )
      )
    {
        fd = ser_azPortStatus[ePort].fd;
        
        /* obtain current settting */
        tcgetattr( fd, &ser_azPortStatus[ePort].zCurrentTmio );
        pzTty = &ser_azPortStatus[ePort].zCurrentTmio;
        
        /* set baudrate */
        speed = ser_TranslateBaudrate( uBaudRate );
        cfsetospeed( pzTty, speed );
        cfsetispeed( pzTty, speed );
            
        /* data bits */
        if( uDataBits == 8u )
        {
            pzTty->c_cflag = (pzTty->c_cflag & ~CSIZE) | CS8; // 8-bit chars
        }
        else if( uDataBits == 7u )
        {
            pzTty->c_cflag = (pzTty->c_cflag & ~CSIZE) | CS7; // 8-bit chars
        }
        else if( uDataBits == 6u )
        {
            pzTty->c_cflag = (pzTty->c_cflag & ~CSIZE) | CS6; // 8-bit chars
        }
        else if( uDataBits == 5u )
        {
            pzTty->c_cflag = (pzTty->c_cflag & ~CSIZE) | CS5; // 8-bit chars
        }
        else
        {
            bSuccess = FALSE;
        }
            
        /* stop bits */
        uStopBits = 1;
        if( uStopBits == 2u )
        {
            pzTty->c_cflag |= CSTOPB;
        }
        else if( uStopBits == 1u )
        {
            pzTty->c_cflag &= ~CSTOPB;
        }
        else
        {
            bSuccess = FALSE;
        }
            
        /* parity settings */
        if( eParity == SER_eParityOdd )
        {
            pzTty->c_cflag |= ( PARENB | PARODD );
        }
        else if( eParity == SER_eParityEven )
        {
            pzTty->c_cflag &= ~PARODD;
            pzTty->c_cflag |= PARENB;
        }
        else if( eParity == SER_eParityNone )
        {
            pzTty->c_cflag &= ~(PARENB | PARODD);
        }
        else
        {
            bSuccess = FALSE;
        }
            
        /*------------------- Special Characters----------------------------*/
        pzTty->c_cc[VMIN]  = 0; // read doesn't block
        pzTty->c_cc[VTIME] = 5; // 0.5 seconds read timeout


        if( bSuccess )
        {
            if ( tcsetattr ( fd, TCSADRAIN, pzTty ) != 0)
            {
                SER_LOG ( SER_ERROR, "error %d from tcsetattr", errno);
                bSuccess = FALSE;
            }
        }
    }
    else
    {
        bSuccess = FALSE;
    }
    
    return fd;
}


/*********************************************************************************************************
 * @brief   Close the serial port.
 *
 * @param   ePort: port being close.
 * @usage
 *
 * @return  TRUE if no error. 
 *          FALSE otherwise.
 *
 * 
********************************************************************************************************/
bool_t SER_Close( SER_ePort_t ePort )
{
    bool_t  bRet = FALSE;
    
    if( ( ser_bInitDone ) &&
        ( ePort < SER_eNumPorts ) )
    {
        if( ser_azPortStatus[ePort].bOpened )
        {
            if( ser_azPortStatus[ePort].fd >= 0 )
            {
                tcsetattr( ser_azPortStatus[ePort].fd, TCSADRAIN, &ser_azPortStatus[ePort].zSavedTmio );
                close( ser_azPortStatus[ePort].fd );
                
                bRet = TRUE;
            }
            
            ser_azPortStatus[ePort].fd = -1;
            ser_azPortStatus[ePort].bOpened = FALSE;
        }
    }
    
    return bRet;
}

/*********************************************************************************************************
 * @brief   read from the specified serial port.
 *          read returns on either the buffer is filled.
 *          or timeout expires.
 *
 * @param   ePort:     port read from.
 * @param   buff:      buffer to write to.
 * @param   bufLen:    len of the buffer.
 * @param   timeout:   time out in msec.
 * @usage
 *
 * @return  the number of bytes read in the buffer.
 *
 * 
********************************************************************************************************/
uint32_t    SER_Read( SER_ePort_t ePort, uint8_t *buff, uint32_t bufLen, uint32_t timeout )
{
    uint32_t lenRead = 0uL;
    
    if( ( ser_bInitDone ) &&
        ( ePort < SER_eNumPorts ) )
    {
        if( ( ser_azPortStatus[ePort].bOpened ) &&
            ( ser_azPortStatus[ePort].fd >= 0 ) )
        {
            struct termios* pzTty = &ser_azPortStatus[ePort].zCurrentTmio;
            
            if( timeout == 0 )
            {
                pzTty->c_cc[VMIN]  = 0;
                pzTty->c_cc[VTIME] =  2; //0.1sec
            }
            else
            {
                pzTty->c_cc[VMIN]  = 0;
                pzTty->c_cc[VTIME] =  ( timeout / 100 ); //0.1sec
            }
    
            tcsetattr (  ser_azPortStatus[ePort].fd, TCSADRAIN, pzTty );
            lenRead = read( ser_azPortStatus[ePort].fd, buff, bufLen );
        }
    }
    
    return lenRead;
}

/*********************************************************************************************************
 * @brief   Write to the specified serial port.
 *
 * @param   buff:       buffer contains the input data.
 * @param   bufLen:     buffer len.
 * @usage
 *
 * @return  TRUE if no error. 
 *          FALSE otherwise.
 *
 * 
********************************************************************************************************/
bool_t    SER_Write( SER_ePort_t ePort, uint8_t *buff, uint32_t bufLen )
{
    bool_t  bRet = FALSE;
    
    if( ( ser_bInitDone ) &&
        ( ePort < SER_eNumPorts ) )
    {
        if( ( ser_azPortStatus[ePort].bOpened ) &&
            ( ser_azPortStatus[ePort].fd >= 0 ) )
        {
            write( ser_azPortStatus[ePort].fd, buff, (size_t)bufLen );
            bRet = TRUE;
        }
    }
}

/*********************************************************************************************************
 * @brief   translate the baudrate to speed_t
 *          if the baudrate is not a commonly recognized baudrate, it defaults to 9600.
 *
 * @param   baudrate:   the input baudrate.
 * @usage
 *
 * @return  the corresponding baudrate in speed_t.
 *
 * 
********************************************************************************************************/
static  speed_t ser_TranslateBaudrate( uint32_t baudrate )
{
    speed_t speed;
    
    switch( baudrate )
    {
        case 0:       speed = B0;       break;
        case 50:      speed = B50;      break;
        case 75:      speed = B75;      break;
        case 110:     speed = B110;     break;
        case 150:     speed = B150;     break;
        case 200:     speed = B200;     break;
        case 300:     speed = B300;     break;
        case 600:     speed = B600;     break;
        case 1200:    speed = B1200;    break;
        case 2400:    speed = B2400;    break;
        case 4800:    speed = B4800;    break;
        case 9600:    speed = B9600;    break;
        case 19200:   speed = B19200;   break;
        case 38400:   speed = B38400;   break;
        case 57600:   speed = B57600;   break;
        case 115200:  speed = B115200;  break;
        //case 128000:  speed = B128000;  break;
        //case 230400:  speed = B230400;  break; 
        //case 256000:  speed = B256000;  break;
        //case 460800:  speed = B460800;  break;
        //case 500000:  speed = B500000;  break;
        //case 576000:  speed = B576000;  break;
        //case 921600:  speed = B921600;  break;
        //case 1000000: speed = B1000000; break; 
        //case 1152000: speed = B1152000; break; 
        //case 1500000: speed = B1500000; break; 
        //case 2000000: speed = B2000000; break;  
        //case 2500000: speed = B2500000; break; 
        //case 3000000: speed = B3000000; break;   
        default:      speed = B9600;    break;
    }
    return speed;
}

/*********************************************************************************************************
 * @brief   Enable the TX for the specified port.
 *
 * @param   ePort:    port being enabled.
 * @usage
 *
 * @return  TRUE if no error. 
 *          FALSE otherwise.
 *
 * 
********************************************************************************************************/
bool_t      SER_TxEnable( SER_ePort_t ePort )
{
    bool_t  bRet = FALSE;
    
    if( ( ser_bInitDone ) &&
        ( ePort < SER_eNumPorts ) &&
        ( ser_azPortStatus[ePort].bOpened )
      )
    {
        SER_LOG( SER_INFO, "SER_TxEnable:[%d]\r\n",ePort );
        ser_azPortStatus[ePort].bEnTx = TRUE;
        bRet = TRUE;
    }
    
    return bRet;
}

/*********************************************************************************************************
 * @brief   Disable the TX for the specified port.
 *
 * @param   ePort: port being operated on.
 * @usage
 *
 * @return  TRUE if no error. 
 *          FALSE otherwise.
 *
 * 
********************************************************************************************************/
bool_t      SER_TxDisable( SER_ePort_t ePort )
{
    bool_t  bRet = FALSE;
    
    if( ( ser_bInitDone ) &&
        ( ePort < SER_eNumPorts ) &&
        ( ser_azPortStatus[ePort].bOpened )
      )
    {
        SER_LOG( SER_INFO, "SER_TxDisable:[%d]\r\n",ePort );
        ser_azPortStatus[ePort].bEnTx = FALSE;
        bRet = TRUE;
    }
    
    return bRet;
}




/*********************************************************************************************************
 * @brief   Enable RX for the specified serial port.
 *
 * @param   ePort:     port being operated on.
 * @usage
 *
 * @return  TRUE if no error. 
 *          FALSE otherwise.
 *
 * 
********************************************************************************************************/
bool_t      SER_RxEnable( SER_ePort_t ePort )
{
    bool_t  bRet = FALSE;
    
    if( ( ser_bInitDone ) &&
        ( ePort < SER_eNumPorts ) &&
        ( ser_azPortStatus[ePort].bOpened )
      )
    {
        SER_LOG( SER_INFO, "SER_RxEnable:[%d]\r\n",ePort );
        ser_azPortStatus[ePort].bEnRx = TRUE;
        bRet = TRUE;
    }
    
    return bRet;
}


/*********************************************************************************************************
 * @brief   Disable RX for the specified serial port.
 *
 * @param   ePort:     port being operated on.
 * @usage
 *
 * @return  TRUE if no error. 
 *          FALSE otherwise.
 *
 * 
********************************************************************************************************/
bool_t      SER_RxDisable( SER_ePort_t ePort )
{
    bool_t  bRet = FALSE;
    
    if( ( ser_bInitDone ) &&
        ( ePort < SER_eNumPorts ) &&
        ( ser_azPortStatus[ePort].bOpened )
      )
    {
        SER_LOG( SER_INFO, "SER_RxDisable:[%d]\r\n",ePort );
        ser_azPortStatus[ePort].bEnRx = FALSE;
        bRet = TRUE;
    }
    
    return bRet;
}



/*********************************************************************************************************
 * @brief   RX and TX work.
 *          it handles all the serial ports on the system. in both RX and TX directions.
 *          it is not intended to handle the actual work resulted from the received message, rather, it is
 *          intended to just push the data traffic to the receiver, and polls the Transmit data trffic 
 *          from the sender.
 * @usage
 *
 * @return  none.
 *
 * 
********************************************************************************************************/
void    SER_RxTx( void )
{
    int i;
    fd_set         inputFdSet, outputFdSet;
    int            idx;
    uint32_t       len;
    
    struct timeval      timeout;
    ser_zPortStatus_t   *pzPortStatus;
   
    int8_t     buff[SER_BUFF_SIZE] ;
    /* Initialize the input/output set */
    FD_ZERO( &inputFdSet );
    FD_ZERO( &outputFdSet );
    
    /* Initialize the timeout structure */
    timeout.tv_sec  = 0;
    timeout.tv_usec = 100000;
    
    /* fill up the fd set */
    for( idx=0u; idx < SER_eNumPorts; idx++ )
    {
        pzPortStatus = &ser_azPortStatus[ idx ];
        
        if(( pzPortStatus->fd >= 0 ) &&
           ( pzPortStatus->bOpened ))
        {
            {
               FD_SET( pzPortStatus->fd, &inputFdSet );
            }

            if( pzPortStatus->bEnTx )
            {
                FD_SET( pzPortStatus->fd, &outputFdSet );
            }
        }
    }
    int  flag = 0;
    /* Select  */
    int n = select( FD_SETSIZE,  &inputFdSet, &outputFdSet, NULL, &timeout );
    /* process the input/output data */
    for( idx=0u; 
         ( idx < SER_eNumPorts) && ( n > 0 ) ; 
         idx++ )
    {
        pzPortStatus = &ser_azPortStatus[ idx ];
        
        if(( pzPortStatus->fd >= 0 ) &&
           ( pzPortStatus->bOpened ))
        {
            
            /* input handling */
            {
                if( FD_ISSET( pzPortStatus->fd, &inputFdSet )  &&
                        ( pzPortStatus->bEnRx ) )
                {
                    /* read from fd and send it up through callback */
                    read( pzPortStatus->fd, &buff[0u], SER_BUFF_SIZE );
                    if (NULL != strstr(buff, "+CMTI"))
                    {
                        memset(buff, 0, SER_BUFF_SIZE);
                        len = read( pzPortStatus->fd, &buff[0u], SER_BUFF_SIZE );
                    }               
            
                    printf("fd:%d LEN:%d buff:%s\n", pzPortStatus->fd, len, buff);
                    /*SER_LOG( SER_INFO, "input:\r\n");
                    scanf("%d", &len);
                    strcpy(&buff[0u], "\n+CMTI: 'SM',3");*/
                    if( len > 0)
                    {
                        SIM800_RecvSMS( buff );
                    }
                }
            }


            /* output handling */
            if(( pzPortStatus->bEnTx ) )
            {
                if( FD_ISSET( pzPortStatus->fd, &outputFdSet ) )
                {
                    write( pzPortStatus->fd, &buff[0u], strlen(buff));
                }
            }
        }
    }
}
